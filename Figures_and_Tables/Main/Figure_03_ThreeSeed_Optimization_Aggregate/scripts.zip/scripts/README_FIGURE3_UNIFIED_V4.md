# GEM Engine — unified Figure 3, panels A through I (V4)

This is an **additive**, publication-focused update. It installs **one new generator command** inside the **original** Figure 3 A–F directory, rather than continuing to create different Figure 3 folders.

## Usage

```bash
unzip -o "$HOME/Downloads/GEM_FIGURE3_UNIFIED_A_TO_I_V4.zip" -d "$HOME/Downloads"
bash "$HOME/Downloads/GEM_FIGURE3_UNIFIED_A_TO_I_V4/INSTALL_AND_GENERATE.command"
```

For subsequent runs (or after moving the publication archive to another Mac):

```bash
bash "$HOME/Desktop/GEM_Publication_Archive/Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/RUN_FIGURE3_A_TO_I.command"
```

Install location:
`GEM_Publication_Archive/Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/`

Results location (each run gets a **new timestamped folder**, prior files are not overwritten):
`GEM_Publication_Archive/Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/outputs/FIGURE3_ALL_NINE_PANELS_V4/run_*/`

Output: **one** combined PDF, PNG, SVG, and full source/audit/aggregation CSVs; main and 300-row sensitivity analysis; JSON methods and timing report.

## A–F (scientific logic frozen and preserved)

A/D: original fractionally tied and **three-seed averaged** 6-variant case-win panels for gsMOBO and NSGA-II. These are unchanged from the previously validated Figure 3 A–F source.

B/E: mean±sample SD of seed-level normalized final HV = `100 * method_final_HV / own_frozen_landscape_HV`.

C/F: worker runtime of each family, as in the original A–F generator, measured from archived scientific results.

## G–I (final requested five-method comparison)

Five methods: **QC-only selector; gsMOBO + SPARC; NSGA-II + SPARC; gsMOBO (with knowledge); NSGA-II (with knowledge).** The last two are the archived `Base` methods with the frozen prior landscape, not no-prior algorithms. These methods use the exact A–F color palette, with a separate five-method legend.

G: **Top-result cases (%)**, NOT averaged win credits. For every seed×biological case at each landscape size, determine which of these **five methods** achieved the **largest final official 128-call HV**. Every method tied to best within `1e-12` absolute HV gets **full credit**. Pool cases from seeds 42/43/44, sum each method's indicator, divide by pooled eligible case count, multiply by 100. No averaging of seed win counts. Bars need **not sum to 100%** because ties count fully; important because QC-only necessarily ties its chosen SPARC when top.

H: **landscape-relative ΔHV** = `100 * (method_final_HV - same seed/case/size frozen_landscape_HV) / frozen_landscape_HV`; mean ± sample SD of the three seed-level means. Unnormalized absolute ΔHV also retained in casewise export. No knowledge-only method gets an artificial zero.

I: archived measured worker optimization runtime for all five methods; **plus preoptimization QC computation and selector decision overhead only if original measured QC timing is available and source hash verifies**. The required timing evidence (if available) is `Figure_03_GHI_QC_Selector/inputs/QC_AND_SELECTOR_MEASURED_TIMINGS.csv`, including exactly 300 measured rows, original `source_file` and `source_sha256`.

**Panels C, F, I use precisely the same figure title (`Runtime`), y-axis wording (`Runtime (min)`), and y-axis range.** When QC preprocessing timing is absent, Panel I is *optimizer runtime only*, explicitly noted in the report but no unsupported "QC cost" text appears in the figure itself. Do not report it as end-to-end elapsed time in manuscript text.

The original **QC-only** binary Ridge selector is not retuned or replaced: one preoptimization `qc_nrmse_max` feature, alpha 6, clipped training target ±20 percentage points, +0.5pp switch threshold, species+problem excluded from each training fold, held-out prediction. It uses source-verified 300 baseline-only QC measurements from all three seeds; no new optimization, FBA, or surrogate training runs are launched.

Primary G–I analysis excludes the historically influential CHO Constrained Product 5K observation from **all three seeds**, totaling 297 source predictions. Full 300-observation analysis is included in separate exported tables; do not represent the exclusion as biologically validated or prospective. A–F use their original complete 25-case cohort unchanged.

## Preservation / reproducibility

* Original `figure_3_seeds.py`, V2 A–F PDF/PNG/SVG, archived science, both G–I earlier versions, and `selector_ghi.py` are **read-only**.
* The installer refuses to overwrite a same-named, locally changed V4 script.
* Every launch writes into a unique timestamped result directory.
* Scientific jobs are parsed **once**, using the original source interpreter, and the frozen QC selector is called exactly as before.
* Because the publication archive can move, paths are archive-relative and plotting environment is rebuilt by existing `SETUP_PLOT_ENV.command` if necessary.
* Installation and rendering requires existing original A–F, G–I, and verified QC source files; failure blocks without modifying earlier outputs.
