# Figure 3 A–I V6 — style-only repair (missing selector no longer blocks)

This package **only re-renders the existing official V4 nine-panel figure** from its archived numeric aggregate CSVs. There is **no selector import, retraining, optimizer run, FBA, or recalculation of scientific statistics**. It preserves the original Figure 3 folder and exact PDF/SVG/PNG names.

## Changes to the nine panels

- In **A–F**, SPARC is **green** (`#009E73`), TRAIL is **yellow** (`#F0B400`).
- In **A and D**, stacked case-win segments are ordered **low-to-high from bottom to top** at each size.
- In **B, C, E, F, G, H, I**, the method bars at every size are sorted **low-to-high left to right**. Attached error bars move with their own methods.
- The landscape-size order remains 5K, 10K, 25K, 50K.
- G–I retain the original separate five-method palette and frozen QC-only scientific outcome. Only the bar order changes.

## Why V5 failed and what V6 fixes

V5 unnecessarily required `Figure_03_GHI_QC_Selector/scripts/selector_ghi.py` even for a pure visual change. V6 **does not require that directory at all**. It uses these already-produced **official V4** summary tables:

```
Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/
  outputs/FIGURE3_ALL_NINE_PANELS_V4/run_*/
    Figure_3_All_Nine_Panels_ThreeSeeds_V4.pdf
    plot_data/ORIGINAL_AF_3SEED_AGGREGATE.csv
    plot_data/GHI_POOLED_TOP_PCT_MAIN_297.csv
```

If those original numeric tables are missing, the installer will stop **before changing any existing script**. A PDF alone is insufficient to reconstruct all statistics or reliably reorder every bar without guessing. Upload the original V4 `run_*` folder, including `plot_data`, if the missing-data message appears.

## Install and generate on Mac

```bash
cd ~/Downloads
unzip -o GEM_FIGURE3_STYLE_UPDATE_V6.zip
bash ~/Downloads/GEM_FIGURE3_STYLE_UPDATE_V6/INSTALL_AND_GENERATE.command
```

This updates the existing generator at `Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/generate_figure3_all_panels.py`, then invokes the **existing** `RUN_FIGURE3_A_TO_I.command` and its plotting-only Python environment.

The existing V4 `run_*` output folder is reused, and the exact previous PDF/SVG/PNG files are overwritten. **No new figure folder and no additional timestamped output directory.** Original source numeric CSVs remain untouched and are SHA256-identified in `FIGURE_3_STYLE_ONLY_UPDATE.json` next to the overwritten figure.

If you move the whole archive to another Mac, the same script redraws the figure from the saved V4 aggregated data; retain those original `plot_data` CSVs alongside it.
