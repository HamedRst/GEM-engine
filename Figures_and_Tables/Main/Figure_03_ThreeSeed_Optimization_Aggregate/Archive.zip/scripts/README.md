# GEM Figure 3 — Three-seed aggregate, self-contained plotting environment (V2)

**What changed from V1:** only the environment launcher and installation package. `figure_3_seeds.py` is **byte-for-byte unchanged** from V1, so the statistical treatment, scientific validation, colors, and six-panel layout are identical.

## One command on a Mac

Download and unzip `GEM_FIGURE3_3SEEDS_PORTABLE_V2.zip` into Downloads, then run:

```bash
bash "$HOME/Downloads/GEM_FIGURE3_3SEEDS_PORTABLE_V2/INSTALL_AND_GENERATE.command"
```

This safely upgrades an existing **unaltered** V1 installation, or creates a new Figure 3 folder in your archive. It then **automatically builds a private virtual environment** and attempts the figure. On the first run, Python needs an internet connection to install plotting packages from PyPI, unless they are cached locally. Later runs reuse the environment.

If the archive is not on the Desktop, pass `--archive /path/to/GEM_Publication_Archive`. This location is used only during installation, never baked into scientific plotting input paths.

## Dedicated plotting-only environment

Inside the archive, in `Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/`:

- `.plot_venv/` — disposable, isolated Python environment, created by `SETUP_PLOT_ENV.command`
- `requirements.txt` — pinned `numpy==2.2.6` and `matplotlib==3.10.7`
- `setup_plot_env.py` — creates / verifies / re-creates environment when relocated
- `RUN_FIGURE.command` — automatically ensures environment then plots; can be called repeatedly
- `figure_3_seeds.py` — **unchanged from V1**

No GEM Engine, COBRApy, FBA solver, optimizer, or system-wide package installation occurs. The source script only imports NumPy and Matplotlib as third-party dependencies; the rest are Python standard-library modules.

A supported Python 3.10, 3.11, 3.12 or 3.13 installation is required on each machine. `python3.13`, `python3.12`, `python3.11`, `python3.10`, `python3` and `python` are checked in that order. A preferred interpreter may be supplied using `GEM_PLOT_PYTHON=/path/to/python3.12`. On a Python 3.14-only computer install Python 3.13 or 3.12 first.

A virtual environment is **not portable between computers** (it contains machine-specific Python binaries and absolute details). The script detects if the archive has moved, deletes **only its own marked disposable `.plot_venv`**, and re-creates it with the same `requirements.txt`—never altering the scientific archive or optimizer environments. It captures the installed transitive dependency versions in `.plot_venv/RESOLVED_PLOT_ENV.txt`.

## Figure scientific rules, unchanged

Two rows: gsMOBO, NSGA-II. Three columns:

- **Winner (A/D):** Average three seed-specific fractional win counts (exact HV ties split at `1e-12`); 25 cases per seed/size/family, stacked totals 25. **No error bars**.
- **HV (B/E):** Each case's `100 × official_final_HV / own_frozen_LANDSCAPE_ONLY_final_HV`. Bars are the average of the three seed-level case means ± **sample SD among seeds**.
- **Runtime (C/F):** Worker-wall minutes of actual optimization jobs (not landscape generation), each seed summarized on the matched case cohort before computing mean ± **sample SD among seeds**. Zero-call `LANDSCAPE_ONLY` excluded.

All four prior sizes (5K, 10K, 25K, 50K), six methods, original method colors, shared legend, 128-call validation, and fail-closed input handling are preserved. **No frontier extensions panel.**

The archive must contain exactly named, archived optimization campaigns under `Results/Optimizations/landscape_seed_42|43|44/prior_5000|10000|25000|50000/` as in V1. **No root-based or user-specific scientific input paths** appear in the plotting scripts.

## Running again after moving the entire archive

From any directory, invoke the installed script by its new path, e.g.:

```bash
bash "<moved-archive>/Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/RUN_FIGURE.command"
```

On the other laptop, install a supported Python first and allow the one-time plotting package download; no script changes are needed. PNG rendering can differ slightly between platforms and fonts; the numeric aggregation uses the same data and pinned top-level library versions. For pixel-level reproducibility, platform/fonts/transitive dependencies must also match.

## Output folder

`Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/outputs/`

- `Figure_3_combined_families_3seeds.{png,pdf,svg}`
- `plot_data/SEED_LEVEL_WINS.csv`
- `plot_data/SEED_LEVEL_HV_AND_RUNTIME.csv`
- `plot_data/AGGREGATE_THREE_SEEDS.csv`
- `plot_data/WINNER_TIE_AUDIT.csv`
- `plot_data/INPUT_SOURCE_AND_METRIC_AUDIT.csv`
- `RUN_REPORT.txt`

If input data is missing or scientifically inconsistent, the script stops and writes `FIGURE_BUILD_DIAGNOSTIC.txt`. The plotting environment can be created successfully even if a campaign fails scientific validation.

## Tests

`python3 -m unittest discover -s tests -v` from this package. The additional environment tests verify owned-directory safety, path relocation detection, version checks, and strict V1 upgrade. No live campaign results are included in the downloaded ZIP, so the full scientific run can only execute when invoked on the archive containing your 12 campaigns.
