# GEM Figure 3 G–I — total win counts / same A–F palette / preservative V3

**Additive update.** V3 installs ONLY uniquely named files into the EXISTING original Figure 3 folder, `Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/`. It does not change the Figure 3 A–F original script, PDF, SVG, PNG, scientific CSVs, recovered surrogate QC data, or old G–I V1/V2 packages/outputs.

When run, it writes to NEW timestamped subfolders under:
`Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/outputs/GHI_FIVE_METHODS_TOTAL_WINS_V3/`.
Thus all previous files/results remain intact, and rerunning creates a new folder instead of overwriting an earlier V3 result.

## Scientific inputs/algorithm (unchanged)

Reads real archived 12 canonical optimizer campaigns: 5 species x 5 problems x 4 landscape sizes x seeds 42, 43, 44. Uses original recovered 300 PASS, zero-live-FBA, preoptimization QC records under `Figure_03_GHI_QC_Selector/inputs`, plus the frozen earlier `selector_ghi.py`. QC-only selector is Ridge with one feature `qc_nrmse_max`, alpha 6, train-only target clipping ±20 percentage points, decision margin +0.5 pp, strict species+problem exclusion folds. No optimizer, FBA, QC training, or landscape generation is rerun.

Methods:

* QC-only selector
* gsMOBO + SPARC
* NSGA-II + SPARC
* gsMOBO (with knowledge), archived `gsMOBO/Base`
* NSGA-II (with knowledge), archived `NSGA-II/Base`

Color palette **exactly reuses the values from existing Figure 3 A–F**: purple `#6A3D9A`, orange `#E69F00`, green `#009E73`, blue `#0072B2`, dark charcoal `#222222`, respectively. Method-specific labels appear in the figure legend. This is a shared color palette, not a direct transfer of A–F *variant* labels (for example, green was used for TRAIL in A–F).

## Panel G: TOTAL win counts (not seed means)

For each `(seed, landscape size, species/problem)` select the largest official final 128-call HV across the five listed methods. If multiple methods are within `1e-12` absolute HV of the best, divide **one** case win credit equally across them, as in Figure 3 A–F. The QC selector necessarily ties its selected SPARC endpoint if it wins. Sum the resulting per-seed fractional win credits across **all three** seeds for every landscape size. **Do not average** the count by three. Totals across the five methods are 72 case-win credits at 5K in the historical CHO-excluded main cohort and 75 case-win credits at 10K, 25K and 50K. These denominators do NOT appear in the plot text. The axis label is only **Win count**. Full 300-case cohort is exported as sensitivity, in which all four sizes have 75 win credits.

## Panel H: landscape-normalized delta HV

For EVERY method, compute `100*(HV_after_128_calls - frozen_same_case_same_seed_same_size_landscape_HV)/frozen_landscape_HV`. This is NOT improvement over Base and does not force knowledge-only baselines to zero. Aggregate within each seed then mean±sample SD across seed-level means; raw ΔHV is also present in case-wise audit CSV.

## Panel I: runtime

If a **source-audited** `Figure_03_GHI_QC_Selector/inputs/QC_AND_SELECTOR_MEASURED_TIMINGS.csv` exists and validates, include measured preoptimization QC-computation + selector-decision overhead in QC-only runtime, with other baselines using their archived measured worker-wall optimization runtimes. Otherwise, show **Optimization runtime** only, using actual measured worker runtimes; do not invent QC computation overhead. The plot deliberately contains NO red warning label or “QC training cost not measured” text. The missing overhead remains explicit in the JSON report, console, and this README. The optimizer-runtime-only version MUST NOT be described as total selector wall time in the paper.

As in A–F, runtime comparisons use the fully matched cohort across sizes/seeds (24 biological cases for the outlier-excluded primary analysis). Primary results exclude the CHO Constrained Product 5K observation **for all three seeds** as historical sensitivity protocol, not independently adjudicated erroneous data; corresponding full 300-case sensitivity summaries also exported. Do not claim independent prospective validation from this retrospective split.

## Running

```bash
unzip -o "$HOME/Downloads/GEM_FIG3_GHI_TOTAL_WIN_COUNTS_PALETTE_V3.zip" -d "$HOME/Downloads"
bash "$HOME/Downloads/GEM_FIG3_GHI_TOTAL_WIN_COUNTS_PALETTE_V3/INSTALL_AND_GENERATE.command"
```

After installation, rerun from the archive:

```bash
bash "$HOME/Desktop/GEM_Publication_Archive/Figures_and_Tables/Main/Figure_03_ThreeSeed_Optimization_Aggregate/scripts/RUN_FIGURE3_GHI_TOTAL_WINS_V3.command"
```

Outputs: a versioned `Figure_3_GHI_TotalWinCounts_LandscapeDeltaHV_3seeds_V3.pdf/png/svg`, per-case and seed-level audit CSVs, three-seed TOTAL count+delta+runtime CSVs for excluded and full-cohort variants, and build report JSON. No old results are removed or replaced.
