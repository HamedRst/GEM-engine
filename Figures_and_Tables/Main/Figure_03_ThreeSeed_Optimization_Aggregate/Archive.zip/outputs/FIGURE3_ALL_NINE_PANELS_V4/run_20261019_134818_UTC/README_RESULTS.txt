Unified Figure 3 A-I. Original A-F scientific calculations are unchanged.
G: pooled top-result percentage with full credit for each tied method.
H: normalized final hypervolume improvement over the same frozen landscape.
C, F, I y-axis: Runtime (min), shared limits.
I overhead: QC computation overhead not measured; I reports measured optimizer runtime only.
Primary: 297 rows. Complete-data sensitivity: 300 rows.
Case-wise sources and summary CSVs are in plot_data/.
